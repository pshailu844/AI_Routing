# Groq Setup Guide - AI Ticket Routing System

## Overview

This system now uses **Groq's Meta Llama 3.3 70B** model for:
- Ticket classification
- RAG-based resolution suggestions
- LLM-as-Judge evaluation

## Quick Setup (3 Steps)

### 1. Get Groq API Key

1. Visit [https://console.groq.com](https://console.groq.com)
2. Sign up for free account
3. Navigate to API Keys section
4. Create new API key
5. Copy the key

**Free Tier Benefits:**
- Fast inference (tokens/second)
- Generous daily limits
- Access to llama-3.3-70b-versatile

### 2. Install Dependencies

```bash
cd ai_ticket_routing_system
pip install -r requirements.txt
```

**Key Dependencies:**
- `langchain-groq` - LangChain integration for Groq
- `groq` - Direct Groq API client
- `sentence-transformers` - For embeddings
- `faiss-cpu` - Vector database
- `streamlit` - Web UI

### 3. Configure Environment

Create `.env` file in project root:

```bash
cp .env.example .env
```

Edit `.env` and add your Groq API key:

```
GROQ_API_KEY=gsk_your_actual_api_key_here
```

## Usage Examples

### Classification

```python
from groq_classifier import GroqTicketClassifier

# Initialize classifier
classifier = GroqTicketClassifier()

# Classify ticket
result = classifier.predict(
    title="Server PROD-WEB-01 is down",
    description="Production server not responding",
    priority="Critical"
)

print(f"Category: {result['category']}")
print(f"Confidence: {result['confidence']:.3f}")
print(f"Reasoning: {result['reasoning']}")
```

### RAG System

```python
from groq_rag_system import GroqRAGSystem

# Initialize RAG
rag = GroqRAGSystem()

# Build index from dataset
rag.build_index('synthetic_tickets_dataset.csv')

# Get AI-generated resolution
result = rag.get_resolution_with_llm(
    title="Database connection timeout",
    description="App cannot connect to database",
    category="Database",
    priority="High"
)

print(f"Resolution:\n{result['resolution']}")
print(f"Estimated Time: {result['estimated_time']:.1f}h")
```

### LLM Judge

```python
from groq_llm_judge import GroqLLMJudge

# Initialize judge
judge = GroqLLMJudge()

# Evaluate classification
scores = judge.evaluate_classification(
    title="Server down",
    description="Production server not responding",
    predicted_category="Infrastructure",
    confidence=0.92,
    reasoning="Keywords indicate server issue",
    ground_truth="Infrastructure"
)

print(f"Relevance: {scores['relevance_score']:.3f}")
print(f"Accuracy: {scores['accuracy_score']:.3f}")
print(f"Overall: {scores['overall_score']:.3f}")
```

## Architecture

### LangChain Pipeline

```
Ticket Input
    ↓
[Groq Classifier] → Category + Confidence
    ↓
[FAISS Search] → Similar Tickets
    ↓
[Groq RAG] → Resolution Suggestion
    ↓
[Groq LLM Judge] → Quality Evaluation
```

### Components

1. **groq_classifier.py**
   - Uses LangChain ChatGroq
   - Structured output with Pydantic
   - Confidence scoring

2. **groq_rag_system.py**
   - FAISS vector database
   - Sentence Transformers embeddings
   - Groq LLM for answer generation

3. **groq_llm_judge.py**
   - Multi-aspect evaluation
   - Relevance, accuracy, completeness
   - Batch evaluation support

## Models Used

- **Classification/RAG/Judge:** llama-3.3-70b-versatile
- **Embeddings:** all-MiniLM-L6-v2 (Sentence Transformers)
- **Vector DB:** FAISS IndexFlatIP (cosine similarity)

## Performance

**Groq Advantages:**
- Ultra-fast inference (~300 tokens/sec)
- Low latency (<1s for most requests)
- Free tier with generous limits
- No GPU required locally

## Troubleshooting

### API Key Issues

```python
# Test API key
import os
from dotenv import load_dotenv
load_dotenv()

api_key = os.getenv("GROQ_API_KEY")
if api_key:
    print("[OK] API key loaded")
else:
    print("[ERROR] API key not found")
```

### Import Errors

```bash
# Ensure all dependencies installed
pip install langchain-groq langchain-community sentence-transformers faiss-cpu
```

### Rate Limits

Free tier limits:
- 30 requests/minute
- 6,000 requests/day
- Sufficient for development/testing

## Migration from Vertex AI

**Removed:**
- google-cloud-aiplatform
- Vertex AI authentication
- GCP project configuration

**Simplified Setup:**
- Single API key (no GCP project)
- No service account needed
- Faster local development

## Next Steps

1. Run test script: `python test_groq_system.py`
2. Start Streamlit UI: `streamlit run streamlit_app.py`
3. Build production API: `fastapi` + `uvicorn`

## Support

- Groq Documentation: https://console.groq.com/docs
- LangChain Groq: https://python.langchain.com/docs/integrations/chat/groq
- Issues: Check API key, rate limits, network connectivity