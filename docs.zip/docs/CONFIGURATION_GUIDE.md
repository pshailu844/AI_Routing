# Configuration Guide

## Overview

All model configurations are now managed through environment variables in the `.env` file. This allows you to easily switch between different models without modifying code.

## Environment Variables

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `GROQ_API_KEY` | Your Groq API key | `gsk_...` |

### Optional Variables (with defaults)

| Variable | Description | Default |
|----------|-------------|---------|
| `GROQ_MODEL` | Groq LLM model name | `llama-3.3-70b-versatile` |
| `EMBEDDING_MODEL` | Sentence transformer model | `sentence-transformers/all-MiniLM-L6-v2` |

## Configuration Files

### .env (Active Configuration)

Your active configuration file containing your API keys and model choices.

```env
# Groq API Configuration
GROQ_API_KEY=your_actual_api_key_here

# Get your API key from: https://console.groq.com/keys
# Free tier available with generous limits

# Model Configuration
GROQ_MODEL=llama-3.3-70b-versatile
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
```

### .env.example (Template)

Template file showing the required structure. Copy this to `.env` and fill in your values.

```env
# Groq API Configuration
GROQ_API_KEY=your_groq_api_key_here

# Get your API key from: https://console.groq.com/keys
# Free tier available with generous limits

# Model Configuration
GROQ_MODEL=llama-3.3-70b-versatile
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
```

## Changing Models

### Change Groq LLM Model

The Groq model is used for:
- Ticket classification
- Resolution generation
- LLM judge evaluation

**Available Groq Models:**
- `llama-3.3-70b-versatile` (default, recommended)
- `llama-3.1-70b-versatile`
- `llama-3.1-8b-instant`
- `mixtral-8x7b-32768`
- `gemma2-9b-it`

**To change:**
```env
GROQ_MODEL=llama-3.1-8b-instant
```

### Change Embedding Model

The embedding model is used for:
- FAISS vector database
- Semantic similarity search

**Popular Models:**
- `sentence-transformers/all-MiniLM-L6-v2` (default, fast, good quality)
- `sentence-transformers/all-mpnet-base-v2` (better quality, slower)
- `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` (multilingual)

**To change:**
```env
EMBEDDING_MODEL=sentence-transformers/all-mpnet-base-v2
```

## How It Works

### Service Initialization

All three service classes now read from environment variables:

1. **GroqTicketClassifier** (`service/groq_classifier.py`)
   ```python
   classifier = GroqTicketClassifier()  # Uses GROQ_MODEL from .env
   ```

2. **GroqRAGSystem** (`service/groq_rag_system.py`)
   ```python
   rag = GroqRAGSystem()  # Uses both GROQ_MODEL and EMBEDDING_MODEL from .env
   ```

3. **GroqLLMJudge** (`service/groq_llm_judge.py`)
   ```python
   judge = GroqLLMJudge()  # Uses GROQ_MODEL from .env
   ```

### Override at Runtime (Optional)

You can still override models programmatically if needed:

```python
# Override Groq model
classifier = GroqTicketClassifier(model_name="llama-3.1-8b-instant")

# Override both models
rag = GroqRAGSystem(
    embedding_model="sentence-transformers/all-mpnet-base-v2",
    llm_model="mixtral-8x7b-32768"
)

# Override LLM judge model
judge = GroqLLMJudge(model_name="gemma2-9b-it")
```

## Best Practices

### 1. Keep .env Secure

- ✅ **DO**: Add `.env` to `.gitignore`
- ❌ **DON'T**: Commit `.env` to version control
- ✅ **DO**: Use `.env.example` as a template

### 2. Model Selection

**For Production:**
- Use `llama-3.3-70b-versatile` for best accuracy
- Use `sentence-transformers/all-MiniLM-L6-v2` for balanced speed/quality

**For Development/Testing:**
- Use `llama-3.1-8b-instant` for faster responses
- Use `sentence-transformers/all-MiniLM-L6-v2` (same as production)

**For Multilingual Support:**
- Use `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`

### 3. API Rate Limits

Monitor your Groq API usage:
- Free tier: 100,000 tokens per day
- If you hit rate limits, consider:
  - Upgrading to paid tier
  - Using faster models (8B instead of 70B)
  - Implementing caching

## Environment Setup

### First-Time Setup

1. **Copy the example file:**
   ```bash
   copy .env.example .env
   ```

2. **Add your API key:**
   - Get key from https://console.groq.com/keys
   - Paste into `.env` file

3. **Optionally customize models:**
   ```env
   GROQ_MODEL=llama-3.3-70b-versatile
   EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
   ```

4. **Restart the application:**
   ```bash
   start_chatbot.bat
   ```

### Switching Environments

**Development:**
```env
GROQ_MODEL=llama-3.1-8b-instant
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
```

**Production:**
```env
GROQ_MODEL=llama-3.3-70b-versatile
EMBEDDING_MODEL=sentence-transformers/all-mpnet-base-v2
```

## Troubleshooting

### "GROQ_API_KEY not found"

**Solution:** Ensure `.env` file exists in project root with:
```env
GROQ_API_KEY=your_actual_key_here
```

### "Model not available"

**Solution:** Check model name spelling and availability:
- Valid Groq models: https://console.groq.com/docs/models
- Valid embedding models: https://huggingface.co/sentence-transformers

### Changes not taking effect

**Solution:** Restart the Flask server:
```bash
# Stop current server (Ctrl+C)
# Restart
start_chatbot.bat
```

### Rate limit errors

**Solution:**
1. Check usage at https://console.groq.com
2. Switch to smaller model:
   ```env
   GROQ_MODEL=llama-3.1-8b-instant
   ```
3. Upgrade to paid tier if needed

## Migration from Hardcoded Values

### Before (Hardcoded)

```python
# Old way - hardcoded in Python files
classifier = GroqTicketClassifier(model_name="llama-3.3-70b-versatile")
rag = GroqRAGSystem(
    embedding_model='all-MiniLM-L6-v2',
    llm_model="llama-3.3-70b-versatile"
)
```

### After (Environment Variables)

```python
# New way - reads from .env file
classifier = GroqTicketClassifier()  # Auto-loads from GROQ_MODEL
rag = GroqRAGSystem()  # Auto-loads from GROQ_MODEL and EMBEDDING_MODEL
```

## Benefits

✅ **Flexibility**: Change models without code changes
✅ **Security**: API keys in `.env`, not in code
✅ **Environment-specific**: Different settings for dev/prod
✅ **Easy deployment**: Just update `.env` file
✅ **Version control safe**: `.env` excluded from git

## Additional Resources

- **Groq Documentation**: https://console.groq.com/docs
- **Groq Models**: https://console.groq.com/docs/models
- **Sentence Transformers**: https://www.sbert.net/
- **Hugging Face Models**: https://huggingface.co/sentence-transformers

---

**Last Updated:** March 2026  
**Version:** 2.0