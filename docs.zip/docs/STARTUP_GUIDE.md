# AI Ticket Routing System - Startup Guide

## Quick Start

### Option 1: Simple Startup (Recommended)
```bash
python chatbot_backend.py
```

### Option 2: Debug Startup (If issues occur)
```bash
python start_server_debug.py
```

---

## Expected Startup Sequence

When you run the backend, you should see:

```
============================================================
AI Ticket Support Chatbot - Backend Server
============================================================

============================================================
Initializing AI Chatbot System...
============================================================

1. Loading Groq Classifier...
   [OK] Classifier ready

2. Loading Groq RAG System...
Loading embedding model: all-MiniLM-L6-v2
(This may take a moment on first run to download the model)
Embedding model loaded successfully
   [OK] RAG system ready

3. Building FAISS index from dataset...
Building RAG index from D:\AI_project\AI_Ticket_Routing\ai_ticket_routing_system\synthetic_tickets_dataset.csv...
Loaded 50 tickets
Generating embeddings...
[Progress bar shown here]
Building FAISS index...
[OK] RAG index built: 50 tickets indexed
   [OK] Indexed 50 tickets
   [OK] Embedding dimension: 384

============================================================
[OK] System initialization complete!
============================================================

Starting Flask server...

Endpoints:
  - POST /chat      : Send chat messages
  - POST /classify  : Classify tickets only
  - POST /similar   : Find similar tickets
  - GET  /stats     : Get database statistics
  - GET  /health    : Health check

============================================================

 * Serving Flask app 'chatbot_backend'
 * Debug mode: on
WARNING: This is a development server. Do not use it in a production deployment.
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
 * Running on http://localhost:5000
```

**⏱️ Startup Time**: 30-60 seconds (first time may take longer to download embedding model)

---

## Accessing the Application

Once the server shows "Running on http://localhost:5000":

1. Open your web browser
2. Navigate to: **http://localhost:5000**
3. You should see the AI Ticket Support Chatbot interface
4. Wait for status to show "Ready" (green) in top-left corner

---

## Testing the System

### 1. Health Check (Terminal Test)
Open a **new** terminal/PowerShell window (keep server running in original):

```powershell
# PowerShell
Invoke-RestMethod -Uri http://localhost:5000/health

# Expected output:
# {
#   "status": "healthy",
#   "classifier_ready": true,
#   "rag_ready": true
# }
```

```bash
# Command Prompt or Git Bash
curl http://localhost:5000/health
```

### 2. Classification Test
```powershell
$body = @{message="Server is down"} | ConvertTo-Json
Invoke-RestMethod -Uri http://localhost:5000/classify -Method Post -Body $body -ContentType "application/json"
```

### 3. Chat Test
```powershell
$body = @{message="Database connection timeout"} | ConvertTo-Json
Invoke-RestMethod -Uri http://localhost:5000/chat -Method Post -Body $body -ContentType "application/json"
```

### 4. Web UI Test
1. Open http://localhost:5000 in browser
2. Click one of the sample question buttons, or
3. Type your own IT support query
4. Verify the AI responds with classification and resolution

---

## Troubleshooting

### Issue 1: Port 5000 Already in Use

**Symptoms:**
- Error: "Address already in use"
- Server won't start

**Solution:**
```powershell
# Find process using port 5000
netstat -ano | findstr :5000

# Kill the process (replace PID with actual process ID)
Stop-Process -Id PID -Force

# Or kill all Python processes
Stop-Process -Name python -Force
```

### Issue 2: Module Not Found

**Symptoms:**
- ImportError or ModuleNotFoundError

**Solution:**
```bash
# Install dependencies
pip install -r requirements_chatbot.txt

# Verify installation
pip list | findstr "flask langchain groq faiss"
```

### Issue 3: GROQ_API_KEY Not Found

**Symptoms:**
- "GROQ_API_KEY not found in environment variables"

**Solution:**
1. Check `.env` file exists in project root
2. Verify it contains: `GROQ_API_KEY=your_key_here`
3. Make sure there are no spaces around the `=`

### Issue 4: CSV File Not Found

**Symptoms:**
- "Dataset not found" error
- FAISS index build fails

**Solution:**
```powershell
# Verify file exists
Test-Path "D:\AI_project\AI_Ticket_Routing\ai_ticket_routing_system\synthetic_tickets_dataset.csv"
# Should return: True

# If false, check if file is in different location
Get-ChildItem -Recurse -Filter "synthetic_tickets_dataset.csv"
```

### Issue 5: Server Starts But Page Won't Load

**Symptoms:**
- Server shows "Running on http://localhost:5000"
- Browser shows "Can't reach this page"

**Possible Causes & Solutions:**

**A. Server Still Initializing**
- Wait 30-60 seconds for FAISS index to build
- Look for "[OK] System initialization complete!" message

**B. Firewall Blocking**
- Check Windows Firewall settings
- Allow Python through firewall

**C. Wrong URL**
- Try: http://127.0.0.1:5000
- Try: http://localhost:5000
- Check browser isn't using a proxy

**D. Server Crashed During Startup**
- Check terminal for error messages
- Run: `python start_server_debug.py` for detailed diagnostics

### Issue 6: Slow Responses

**Symptoms:**
- Chat responses take 10+ seconds

**Normal Behavior:**
- First query: 5-10 seconds (model initialization)
- Subsequent queries: 2-5 seconds
- This is normal for Groq API + FAISS retrieval

---

## Performance Notes

### Startup Performance
- **First Run**: 60-120 seconds (downloads embedding model ~90MB)
- **Subsequent Runs**: 30-60 seconds (loads from cache)
- **FAISS Index Build**: ~20 seconds for 50 tickets

### Runtime Performance
- **Classification**: ~1-2 seconds
- **FAISS Search**: <100ms
- **LLM Response**: 2-4 seconds (Groq API)
- **Total Chat Response**: 3-6 seconds

---

## Verification Checklist

Before reporting issues, verify:

- [ ] Python 3.8+ installed (`python --version`)
- [ ] All dependencies installed (`pip list | findstr "flask langchain"`)
- [ ] `.env` file exists with GROQ_API_KEY
- [ ] CSV file exists at correct path
- [ ] Port 5000 not in use by other application
- [ ] No firewall blocking localhost:5000
- [ ] Server shows "System initialization complete!"
- [ ] Browser can access http://localhost:5000

---

## Manual Verification Steps

### Step 1: Verify File Structure
```
AI_Ticket_Routing/
├── chatbot_backend.py          [OK] Backend server
├── chatbot.html                [OK] Frontend HTML
├── chatbot.js                  [OK] Frontend JavaScript
├── chatbot.css                 [OK] Frontend styles
├── .env                        [OK] Environment variables
├── requirements_chatbot.txt    [OK] Dependencies
└── ai_ticket_routing_system/
    ├── groq_classifier.py      [OK] Classifier
    ├── groq_rag_system.py      [OK] RAG system
    └── synthetic_tickets_dataset.csv  [OK] 50 tickets
```

### Step 2: Check Environment
```bash
# Check Python
python --version
# Should be 3.8 or higher

# Check pip packages
pip list | findstr "flask"
pip list | findstr "langchain"
pip list | findstr "groq"
pip list | findstr "faiss"
```

### Step 3: Test GROQ API Key
```python
# Create test_groq.py
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("GROQ_API_KEY")

if api_key:
    print(f"[OK] API Key found (length: {len(api_key)})")
    print(f"  First 10 chars: {api_key[:10]}...")
else:
    print("[ERROR] API Key not found!")
```

Run: `python test_groq.py`

### Step 4: Test Imports
```python
# Create test_imports.py
try:
    from ai_ticket_routing_system.groq_classifier import GroqTicketClassifier
    print("[OK] Classifier imports OK")
    
    from ai_ticket_routing_system.groq_rag_system import GroqRAGSystem
    print("[OK] RAG system imports OK")
    
    import pandas as pd
    df = pd.read_csv("ai_ticket_routing_system/synthetic_tickets_dataset.csv")
    print(f"[OK] Dataset loads OK ({len(df)} tickets)")
    
except Exception as e:
    print(f"[ERROR] Error: {e}")
```

Run: `python test_imports.py`

---

## Getting Help

If issues persist after troubleshooting:

1. Check VERIFICATION_REPORT.md for detailed system status
2. Run `python start_server_debug.py` for diagnostics
3. Check server terminal for error messages
4. Ensure FAISS index completes building (look for "[OK] Indexed 50 tickets")

---

## Success Indicators

✅ **Server Started Successfully When You See:**
```
[OK] System initialization complete!
Running on http://localhost:5000
```

✅ **System Working When:**
- Browser loads chatbot interface
- Status shows "Ready" (green)
- Sample questions work
- Info panel updates with classification

✅ **FAISS DB Loaded When You See:**
```
Building FAISS index from dataset...
Loaded 50 tickets
Generating embeddings...
Building FAISS index...
[OK] RAG index built: 50 tickets indexed
[OK] Indexed 50 tickets
[OK] Embedding dimension: 384
```

---

**Last Updated**: March 22, 2026  
**System Version**: 1.0  
**Verified Working**: Yes [OK]