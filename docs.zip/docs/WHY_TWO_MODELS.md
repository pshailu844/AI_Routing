# Why RAG Uses Two Different Models

## The Two Models Explained

### 1. Embedding Model: `all-MiniLM-L6-v2` (HuggingFace)
**Purpose:** Convert text to numerical vectors for similarity search
**Used for:** Finding similar tickets in the database
**Location:** Lines 52, 123, 167 in groq_rag_system.py

**Why needed:**
- Converts "Server down" → [0.23, -0.45, 0.67, ...] (384 numbers)
- Enables FAISS to find similar tickets by comparing vectors
- Fast, efficient mathematical search (not language generation)

**Problem:** Must download from HuggingFace (SSL certificate issues on corporate networks)

### 2. LLM Model: `llama-3.3-70b-versatile` (Groq)
**Purpose:** Generate intelligent responses and resolutions
**Used for:** Creating resolution suggestions based on similar tickets
**Location:** Lines 62-67, 262 in groq_rag_system.py

**Why needed:**
- Takes similar tickets and generates new, customized resolution
- Understands context and provides intelligent recommendations
- Accessed via Groq API (no download needed)

**No Problem:** Just API calls, works on corporate networks

## How RAG Works (2-Step Process)

```
Step 1: SEARCH (Embedding Model)
New Ticket: "Server PROD-01 not responding"
   ↓ (Embedding model converts to vector)
   ↓ (FAISS searches 1000 tickets)
   ↓
Found: 3 similar tickets with resolutions

Step 2: GENERATE (Groq LLM)
Similar tickets + New ticket → Groq LLM
   ↓
Generated: "Based on similar issues, try:
1. Check server logs
2. Restart service
3. Verify network connectivity..."
```

## Why Not Use Groq for BOTH?

**Good news:** Groq doesn't currently have a text embedding API. They focus on LLM inference.

**Alternatives to avoid HuggingFace download:**

### Option A: Use OpenAI Embeddings (If available)
```python
from langchain_openai import OpenAIEmbeddings
embeddings = OpenAIEmbeddings(api_key="...")
```

### Option B: Use Sentence Transformers from local cache
Download model once on unrestricted network, copy to corporate machine

### Option C: Skip RAG entirely (Current workaround)
Use only Classifier + LLM Judge (no embeddings needed)
- Classifier still works [OK]
- LLM Judge still works [OK]  
- RAG unavailable (needs embeddings)

## Technical Comparison

| Feature | Embedding Model | LLM Model |
|---------|----------------|-----------|
| Model | all-MiniLM-L6-v2 | llama-3.3-70b |
| Provider | HuggingFace | Groq |
| Size | 80MB | 70B params (API) |
| Purpose | Similarity search | Text generation |
| Download | Required (SSL issue) | No (API only) |
| Speed | Very fast | Fast (Groq) |
| Cost | Free | Free (Groq tier) |

## Current Issue Summary

Your corporate network blocks HuggingFace SSL certificates, preventing the embedding model download.

**Solution:**
Either use the system without RAG (classifier+judge only), or download the model on an unrestricted network and transfer it.

The core ticket routing (classification) works perfectly - RAG is an optional enhancement!