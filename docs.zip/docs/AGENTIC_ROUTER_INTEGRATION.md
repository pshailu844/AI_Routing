# Agentic AI Router Integration Guide

This guide shows how to integrate the new `GroqAgenticRouter` into your application.

## What is the Agentic Router?

The **Agentic AI Router** uses Groq's Llama 3.3 70B model to make intelligent routing decisions based on:
- Classification confidence and quality scores
- Similarity to historical tickets
- F1 score metrics
- Ticket context (priority, category, description)
- Production impact and security concerns

Unlike rule-based routing, the AI agent can:
- ✅ Provide detailed reasoning for decisions
- ✅ Adjust priorities based on severity
- ✅ Give actionable recommendations
- ✅ Handle edge cases with nuanced judgment

## Model Used

**Model:** `llama-3.3-70b-versatile` (same as classifier and RAG system)
**No new dependencies needed** - uses existing LangChain and Groq setup

## Integration in app.py

### Option 1: Replace Rule-Based Routing (Full Agentic)

```python
from service import GroqAgenticRouter

# Initialize in initialize_system()
agentic_router = None

def initialize_system():
    global classifier, rag_system, judge, agentic_router, is_initialized
    
    # ... existing initialization ...
    
    # Initialize Agentic Router
    logger.info("4. Loading Groq Agentic Router...")
    agentic_router = GroqAgenticRouter()
    logger.info("   [OK] Agentic Router ready")

# Use in /chat endpoint
@app.route('/chat', methods=['POST'])
def chat():
    # ... classification and RAG steps ...
    
    # Get agentic routing decision
    routing_decision = agentic_router.route_ticket(
        title=message,
        description=message,
        category=category,
        priority="Medium",
        confidence=confidence,
        quality_grade=quality_grade,
        f1_score=f1_score,
        max_similarity=max_similarity,
        is_new_category=is_new_category,
        similar_tickets=similar_tickets[:3],
        additional_context=f"Similar tickets found: {len(similar_tickets)}"
    )
    
    # Use routing decision in response
    response_data = {
        'response': ai_response,
        'classification': {
            'category': category,
            'confidence': float(confidence),
            'reasoning': classification.get('reasoning', ''),
            'is_new_category': is_new_category
        },
        'routing': {
            'team': routing_decision['full_team_assignment'],
            'level': routing_decision['routing_level'],
            'priority_adjustment': routing_decision['priority_adjustment'],
            'confidence': routing_decision['confidence'],
            'reasoning': routing_decision['reasoning'],
            'estimated_time': routing_decision['estimated_resolution_time'],
            'recommended_actions': routing_decision['recommended_actions'],
            'requires_escalation': routing_decision['requires_escalation'],
            'is_agentic': routing_decision['is_agentic']
        },
        # ... rest of response ...
    }
```

### Option 2: Hybrid Approach (Rule-Based + AI Fallback)

Use rule-based for simple cases, AI for complex ones:

```python
# Determine which routing to use
use_agentic_routing = (
    is_new_category or  # Novel issues
    quality_grade == 'D' or  # Poor quality
    category == 'Security' or  # Security issues
    'production' in message.lower() or  # Production impact
    f1_score < 0.6  # Low confidence
)

if use_agentic_routing:
    # Use AI-powered routing for complex cases
    routing_decision = agentic_router.route_ticket(
        title=message,
        description=message,
        category=category,
        priority="Medium",
        confidence=confidence,
        quality_grade=quality_grade,
        f1_score=f1_score,
        max_similarity=max_similarity,
        is_new_category=is_new_category,
        similar_tickets=similar_tickets[:3]
    )
    
    escalation_team = routing_decision['full_team_assignment']
    routing_reasoning = routing_decision['reasoning']
    is_agentic = True
else:
    # Use fast rule-based routing for simple cases
    base_team = team_mapping.get(category, 'General Support Team')
    
    if confidence >= 0.75 and quality_grade in ['A', 'B']:
        team_level = "L1 Support"
    else:
        team_level = "L2 Support"
    
    escalation_team = f"{base_team} ({team_level})"
    routing_reasoning = "Rule-based routing"
    is_agentic = False
```

### Option 3: Toggle via Environment Variable

Add to `.env`:
```
USE_AGENTIC_ROUTING=true
```

In app.py:
```python
import os

USE_AGENTIC_ROUTING = os.getenv("USE_AGENTIC_ROUTING", "false").lower() == "true"

def get_routing_decision(...):
    if USE_AGENTIC_ROUTING:
        return agentic_router.route_ticket(...)
    else:
        # Rule-based logic
        return {...}
```

## Testing the Agentic Router

### Test Standalone

```bash
python -m service.groq_agentic_router
```

This will run a test routing decision and show the output.

### Test via API

```python
import requests

response = requests.post('http://localhost:5000/chat', json={
    'message': 'Production database is down, users cannot login'
})

print(response.json()['routing'])
```

## Output Example

```json
{
  "routing": {
    "team": "Database Admin Team (Manual Review Required)",
    "level": "Manual Review Required",
    "priority_adjustment": "Escalate",
    "confidence": 0.95,
    "reasoning": "This is a critical production outage affecting authentication. High urgency requires immediate senior DBA review. The production impact and authentication failure suggest potential cascading issues.",
    "estimated_time": 1.5,
    "recommended_actions": [
      "Immediately escalate to senior DBA on-call",
      "Check database server health and connections",
      "Review recent deployment or configuration changes",
      "Verify authentication service dependencies",
      "Prepare rollback plan if recent changes detected"
    ],
    "requires_escalation": true,
    "is_agentic": true
  }
}
```

## Performance Considerations

**Agentic Routing:**
- ⏱️ Adds ~200-500ms per request (extra AI call)
- 💰 Costs ~$0.0001-0.0003 per routing decision
- 🎯 Provides more nuanced, context-aware decisions

**Rule-Based Routing:**
- ⏱️ <1ms per request
- 💰 Free
- 🎯 Fast, deterministic, predictable

**Recommendation:**
- Use **Hybrid Approach** for best balance
- Agentic for complex/critical cases
- Rule-based for simple/routine cases

## When to Use Agentic Routing

✅ **Good Use Cases:**
- Security incidents requiring nuanced judgment
- Production outages with cascading effects
- Novel issues not in knowledge base
- High-value customers requiring special attention
- Tickets with conflicting signals (high confidence but low similarity)

❌ **Don't Need Agentic:**
- Simple password resets
- Common known issues
- Clear-cut L1 support tickets
- High confidence + high similarity cases

## Monitoring and Logging

The agentic router includes detailed logging:

```
[Agentic Router] Analyzing ticket: Production database server PROD-DB...
[Agentic Router] Decision: Manual Review Required
[Agentic Router] Team: Database Admin Team
[Agentic Router] Confidence: 0.950
```

Check logs at: `logs/ai_ticket_routing_YYYY-MM-DD.log`

## Fallback Safety

If the AI router fails (API error, rate limit, parsing error), it automatically falls back to rule-based routing:

```python
{
    'is_agentic': False,
    'reasoning': 'Fallback rule-based routing due to AI error',
    ...
}
```

This ensures your system **never fails** even if Groq API is down.

## Next Steps

1. Choose integration approach (Option 1, 2, or 3)
2. Update `app.py` with routing code
3. Test with sample tickets
4. Monitor performance and costs
5. Adjust thresholds as needed

## Cost Analysis

**Estimated costs** (based on Groq pricing):

| Volume | Rule-Based | Agentic (Full) | Hybrid |
|--------|-----------|----------------|--------|
| 100 tickets/day | $0 | $0.03/day | $0.01/day |
| 1,000 tickets/day | $0 | $0.30/day | $0.10/day |
| 10,000 tickets/day | $0 | $3.00/day | $1.00/day |

**Hybrid approach** gives you 90% of the benefits at 30% of the cost!