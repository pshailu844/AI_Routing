# AI Ticket Routing System - Application Flow

## Quick Overview
**User Query → Groq Classification → FAISS Search → LLM Judge → Response**

---

## Detailed Flow

### 1️⃣ User Submits Ticket
```
User enters IT issue → Frontend (chatbot.html)
```

### 2️⃣ Backend Processing
```
chatbot_backend.py receives request
    ↓
groq_classifier.py analyzes ticket
    → Category (Infrastructure, Database, Network, etc.)
    → Priority (High, Medium, Low)
    → Confidence Score
```

### 3️⃣ RAG System Search
```
groq_rag_system.py searches FAISS database
    → Finds 3 most similar past tickets
    → Retrieves resolutions
    → Calculates similarity scores
```

### 4️⃣ LLM Judge Evaluation
```
groq_llm_judge.py evaluates quality
    → Accuracy metrics
    → F1 Score
    → Semantic similarity
    → Quality grade (A-D)
```

### 5️⃣ Response Generation
```
Backend generates response:
    [OK] Classification details
    [OK] Similar ticket resolutions
    [OK] Step-by-step solution
    [OK] Escalation recommendation
```

### 6️⃣ Frontend Display
```
chatbot.js displays:
    [OK] Bot response with solution
    [OK] Classification card (category, confidence)
    [OK] Escalation status
    [OK] Evaluation metrics
    [OK] Similar tickets
    [OK] Copy/Share buttons
```

---

## Key Features Flow

### 🔍 Browse Tickets
```
Click "Browse Tickets" → View categories → Select category → See all tickets → Click ticket → Auto-fill chat
```

### 📊 New Tickets Analysis
```
Click "New Tickets" → View new tickets table → See similarity scores → Click "Discuss" → Analyze in chat
```

### 📈 Database Stats
```
Click "Database Stats" → View total tickets, categories, priorities, avg resolution time
```

### 🗑️ Clear Chat
```
Click "Clear Chat" → Confirm → Reset to welcome screen
```

---

## Technology Stack

| Component | Technology |
|-----------|-----------|
| **Frontend** | HTML, CSS, JavaScript |
| **Backend** | Python Flask |
| **LLM** | Groq (Llama-3.1-70b) |
| **Vector DB** | FAISS |
| **Classification** | Groq Classifier |
| **RAG** | FAISS + Groq |
| **Evaluation** | LLM-as-Judge |

---

## Data Flow Diagram

```
┌─────────────┐
│    User     │
└──────┬──────┘
       │ Query
       ▼
┌─────────────────────┐
│  Frontend (HTML/JS) │
└──────┬──────────────┘
       │ POST /chat
       ▼
┌─────────────────────┐
│ Backend (Flask)     │
│  - Receive query    │
└──────┬──────────────┘
       │
       ├─────────────────────────┐
       │                         │
       ▼                         ▼
┌──────────────┐        ┌────────────────┐
│ Groq         │        │ FAISS Vector   │
│ Classifier   │        │ Database       │
│              │        │                │
│ ↓ Category   │        │ ↓ Similar      │
│ ↓ Confidence │        │   Tickets (3)  │
└──────┬───────┘        └────────┬───────┘
       │                         │
       └──────────┬──────────────┘
                  │
                  ▼
          ┌───────────────┐
          │ LLM Judge     │
          │ Evaluation    │
          └───────┬───────┘
                  │
                  ▼
          ┌───────────────┐
          │ Generate      │
          │ Response      │
          └───────┬───────┘
                  │ JSON Response
                  ▼
          ┌───────────────┐
          │ Frontend      │
          │ Display       │
          └───────────────┘
```

---

## File Structure

```
AI_Ticket_Routing/
│
├── Frontend
│   ├── chatbot.html          # UI
│   ├── chatbot.css           # Styling
│   ├── chatbot.js            # Client logic
│   └── icon/                 # SVG icons
│
├── Backend
│   ├── chatbot_backend.py    # Flask API
│   └── ai_ticket_routing_system/
│       ├── groq_classifier.py    # Classification
│       ├── groq_rag_system.py    # RAG search
│       ├── groq_llm_judge.py     # Evaluation
│       └── synthetic_tickets_dataset.csv
│
└── Data
    ├── synthetic_tickets_dataset.csv    # Training data
    └── new_tickets_dataset.csv          # New tickets
```

---

## API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Check server status |
| `/chat` | POST | Process user query |
| `/stats` | GET | Get database statistics |
| `/all_tickets` | GET | Get all tickets |
| `/new_tickets` | GET | Get new tickets analysis |

---

## Quick Start

```bash
# 1. Start Backend
python chatbot_backend.py

# 2. Open Frontend
start chatbot.html

# 3. Ask Questions
"Server is down" → Get classification + solution
```

---

**That's it! Simple, fast, AI-powered ticket routing! 🚀**