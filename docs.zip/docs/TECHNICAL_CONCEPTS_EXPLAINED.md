# Technical Concepts & Metrics - Detailed Explanation

## **TABLE OF CONTENTS**
1. [Core Concepts](#core-concepts)
2. [Metrics & Scores](#metrics--scores)
3. [Where Each Concept is Used](#where-each-concept-is-used)
4. [Complete Sequence of Operations](#complete-sequence-of-operations)

---

## **CORE CONCEPTS**

### **1. EMBEDDINGS (Vector Representations)**

**What it is:**
Converting text into numerical vectors (arrays of numbers)

**Simple Explanation:**
- Text: "Database connection failed"
- Embedding: [0.23, -0.45, 0.67, ..., 0.12] (384 numbers)

**Why we need it:**
Computers can't compare text directly. They need numbers.

**Example:**
```
Text 1: "Database timeout"
Embedding 1: [0.8, 0.2, 0.1, 0.5, ...]

Text 2: "DB connection slow"  
Embedding 2: [0.7, 0.3, 0.2, 0.4, ...]

Similar meaning → Similar numbers!
```

**Technical Details:**
- **Size**: 384 dimensions (384 numbers per text)
- **Model**: `sentence-transformers/all-MiniLM-L6-v2`
- **How**: Neural network converts text → numbers
- **Property**: Similar meanings → close vectors in 384-dimensional space

**Where used in our system:**
1. **Building FAISS Index**: Convert all 1000 tickets to embeddings
2. **Search**: Convert user query to embedding, find similar embeddings

---

### **2. SENTENCE TRANSFORMATION (SentenceTransformer)**

**What it is:**
A pre-trained AI model that converts sentences/paragraphs into embeddings

**Simple Explanation:**
It's like a translator:
- Input: English sentence
- Output: 384 numbers that capture meaning

**How it works:**
```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')

text = "Server is down"
embedding = model.encode(text)
# Result: array([0.23, -0.45, 0.67, ..., 0.12])  # 384 numbers
```

**Why this model?**
- **Fast**: Processes text quickly
- **Accurate**: Good at capturing meaning
- **Lightweight**: Only 80MB
- **Free**: No API costs

**Training:**
Trained on millions of sentence pairs to learn:
- "Server down" ≈ "Server not responding"
- "Login failed" ≈ "Cannot authenticate"

**Where used:**
- `service/groq_rag_system.py`
- Converts tickets and queries to embeddings

---

### **3. VECTOR (Mathematical Representation)**

**What it is:**
An array of numbers representing position in multi-dimensional space

**Simple Analogy:**
```
1D (line):     Position = 5
2D (plane):    Position = (3, 7)
3D (space):    Position = (3, 7, 2)
384D (our embeddings): Position = [0.23, -0.45, ..., 0.12]
```

**In our system:**
Each ticket is a point in 384-dimensional space

**Visual (simplified to 2D):**
```
        │
    T3  │  T2
        │     
    T1  │        Query
─────────┼────────────
        │  T4
        │
```

**Key property:**
Distance between vectors = Similarity between texts

**Mathematical formula:**
```
Cosine Similarity = (A · B) / (|A| × |B|)
Result: Number between -1 and 1
- 1.0 = Identical
- 0.0 = Unrelated
- -1.0 = Opposite
```

**Where used:**
- FAISS index stores and searches vectors
- Similarity calculation uses vector math

---

### **4. SEMANTIC SEARCH (Meaning-Based Search)**

**What it is:**
Finding similar content by meaning, not just keywords

**Comparison:**

#### **Keyword Search (Old Way):**
```
Query: "database slow"
Matches: Documents containing words "database" AND "slow"
Misses: "DB performance issue", "SQL query timeout"
```

#### **Semantic Search (Our Way):**
```
Query: "database slow"
Finds:
  1. "DB performance issue" (0.85 similarity)
  2. "SQL query timeout" (0.82 similarity)
  3. "database slow" (1.0 similarity)
```

**How it works:**
1. Convert query to embedding
2. Find embeddings close in vector space
3. Return corresponding tickets

**Example:**
```
User Query: "Cannot login to email"

Keyword Search finds:
- "Login", "email" keywords

Semantic Search finds:
- "Outlook authentication failed" (no matching keywords!)
- "Mail server password expired"
- "Cannot access inbox"

Reason: All have similar MEANING!
```

**Where used:**
- `rag_system.search_similar()` in `groq_rag_system.py`
- FAISS performs semantic search on ticket embeddings

---

### **5. FAISS (Vector Search Engine)**

**What it is:**
Facebook AI Similarity Search - ultra-fast library for finding similar vectors

**Simple Explanation:**
Like Google for vectors - searches millions of embeddings in milliseconds

**How it works:**
```python
# Build index (one time)
index = faiss.IndexFlatIP(384)  # 384 dimensions
index.add(ticket_embeddings)    # Add 1000 ticket vectors

# Search (every query)
query_embedding = model.encode("Database timeout")
similarities, indices = index.search(query_embedding, k=3)
# Returns: 3 most similar tickets in ~5ms
```

**Speed Comparison:**
| Method | Time for 1M vectors |
|--------|---------------------|
| Loop through all | ~30 seconds |
| Database query | ~10 seconds |
| FAISS | ~5 milliseconds |

**Why FAISS?**
- **Fast**: Optimized C++ code
- **Scalable**: Handles billions of vectors
- **Accurate**: Finds true nearest neighbors

**Types of FAISS Indices:**
- **IndexFlatIP** (our choice): Inner Product, exact search
- **IndexIVFFlat**: Fast approximate search
- **IndexHNSW**: Graph-based search

**Where used:**
- `service/groq_rag_system.py`
- Stores ticket embeddings
- Searches for similar tickets

---

## **METRICS & SCORES**

### **1. CONFIDENCE SCORE (0.0 - 1.0)**

**What it is:**
How sure the AI is about its prediction

**Range explained:**
```
0.0 - 0.3 = Very uncertain (random guess)
0.3 - 0.5 = Low confidence (probably wrong)
0.5 - 0.7 = Medium confidence (could be right)
0.7 - 0.9 = High confidence (likely correct)
0.9 - 1.0 = Very high confidence (almost certain)
```

**Example:**
```
Ticket: "Database connection timeout in production SQL server"

Category: Database
Confidence: 0.95  ← 95% sure this is Database issue

Why high?
- Multiple clear indicators: "database", "SQL", "connection"
- No conflicting signals
- Matches training data patterns
```

**Calculation:**
AI model outputs probabilities for each category:
```
Infrastructure: 0.05
Database: 0.95  ← Highest, selected as category
Security: 0.00
Network: 0.00
Access: 0.00
Application: 0.00
```
Confidence = probability of selected category

**Where used:**
- `classifier.predict()` returns confidence
- Used in routing decision (high confidence → L1 Support)
- Part of F1 score calculation

**Why 0-1 range?**
- **0.0 = 0% probability** (impossible)
- **0.5 = 50% probability** (coin flip)
- **1.0 = 100% probability** (certain)
- Standard in machine learning for probabilities

---

### **2. SIMILARITY SCORE (0.0 - 1.0)**

**What it is:**
How similar two texts are (measured by vector distance)

**Range explained:**
```
0.0 - 0.3 = Not similar (different topics)
0.3 - 0.5 = Somewhat related
0.5 - 0.7 = Related (same domain)
0.7 - 0.9 = Very similar (same issue type)
0.9 - 1.0 = Almost identical (same ticket)
```

**Example:**
```
Query: "Database connection timeout"

Similar Tickets Found:
1. "SQL server connection failed" - Similarity: 0.87
   (Very similar - same problem, different words)

2. "DB query performance slow" - Similarity: 0.65
   (Related - database issue, but different symptom)

3. "Network router down" - Similarity: 0.12
   (Not similar - different category)
```

**Calculation:**
```
Cosine Similarity = (Query Vector · Ticket Vector) / (|Query| × |Ticket|)

Example:
Query embedding: [0.8, 0.6, 0.1, ...]
Ticket embedding: [0.7, 0.5, 0.2, ...]

Dot product: 0.8×0.7 + 0.6×0.5 + 0.1×0.2 + ...
Normalize by lengths
Result: 0.87
```

**Where used:**
- `rag_system.search_similar()` returns similarity scores
- Used to find top-3 similar tickets
- Part of F1 score (recall calculation)

**Why 0-1 range?**
- **Cosine similarity** is normalized to [-1, 1]
- We normalize embeddings, so result is always [0, 1]
- **1.0 = same direction** (identical meaning)
- **0.0 = perpendicular** (unrelated)

---

### **3. F1 SCORE (0.0 - 1.0)**

**What it is:**
Combined metric balancing precision and recall

**Formula:**
```
F1 = 2 × (Precision × Recall) / (Precision + Recall)

Where:
Precision = Confidence (how sure about classification)
Recall = Average similarity (how well we found similar tickets)
```

**Range explained:**
```
0.0 - 0.3 = Poor (unreliable prediction)
0.3 - 0.5 = Fair (needs review)
0.5 - 0.7 = Good (acceptable)
0.7 - 0.9 = Very Good (reliable)
0.9 - 1.0 = Excellent (highly reliable)
```

**Example Calculation:**
```
Scenario 1: High confidence, good similar tickets
Precision (Confidence): 0.90
Recall (Avg similarity): 0.85
F1 = 2 × (0.90 × 0.85) / (0.90 + 0.85)
F1 = 2 × 0.765 / 1.75
F1 = 0.87 (Very Good)

Scenario 2: Medium confidence, low similarity
Precision (Confidence): 0.65
Recall (Avg similarity): 0.40
F1 = 2 × (0.65 × 0.40) / (0.65 + 0.40)
F1 = 2 × 0.26 / 1.05
F1 = 0.49 (Fair - needs review)
```

**Why both matter:**
```
High Confidence + Low Similarity:
- AI is sure, but no similar tickets found
- Might be new issue type
- F1 = Low → Route to Manual Review

Low Confidence + High Similarity:
- AI unsure, but found very similar tickets
- Can use historical solutions
- F1 = Medium → Route to L2 Support

High Confidence + High Similarity:
- AI sure AND found similar tickets
- Best case for automation
- F1 = High → Route to L1 Support
```

**Where used:**
- `calculate_f1_score()` in `app.py`
- Used by `agentic_router` for routing decision
- Quality indicator for response

**Why F1 (not just accuracy)?**
- **Balances precision and recall** (harmonic mean)
- **Penalizes extremes** (0.9 precision + 0.1 recall = 0.18 F1, not 0.5)
- **Industry standard** for classification quality

---

### **4. QUALITY GRADE (A/B/C/D)**

**What it is:**
Letter grade for classification and resolution quality

**Grading Scale:**
```
A: 0.90 - 1.00 (Excellent - Production ready)
B: 0.75 - 0.89 (Good - Minor review)
C: 0.60 - 0.74 (Acceptable - Needs review)
D: 0.00 - 0.59 (Poor - Manual intervention)
```

**What it measures:**

#### **For Classification:**
```python
Evaluation:
- Relevance: Does category match content? (0-1)
- Accuracy: Is confidence appropriate? (0-1)
- Completeness: Is reasoning sound? (0-1)

Average: (Relevance + Accuracy + Completeness) / 3

Example:
Relevance: 0.95 (perfect match)
Accuracy: 0.90 (confidence justified)
Completeness: 0.85 (good reasoning)
Overall: 0.90 → Grade A
```

#### **For Resolution:**
```python
Evaluation:
- Relevance: Addresses the issue? (0-1)
- Accuracy: Technically correct? (0-1)
- Completeness: All steps included? (0-1)

Average: (Relevance + Accuracy + Completeness) / 3

Example:
Relevance: 0.80 (good match)
Accuracy: 0.75 (mostly correct)
Completeness: 0.70 (some steps missing)
Overall: 0.75 → Grade B
```

**Where used:**
- `judge.evaluate_classification()`
- `judge.evaluate_resolution()`
- Routing decision input
- Quality monitoring

**Why letter grades?**
- **Easy to understand** (like school grades)
- **Clear action items** (D → escalate, A → approve)
- **Standard communication** (teams know what A/B/C/D means)

---

## **WHERE EACH CONCEPT IS USED**

### **COMPONENT-BY-COMPONENT BREAKDOWN**

#### **1. GroqRAGSystem (service/groq_rag_system.py)**

**Uses:**
- ✅ **Embeddings**: Converts tickets to vectors
- ✅ **Sentence Transformation**: SentenceTransformer model
- ✅ **Vectors**: Stores 384-dimensional ticket representations
- ✅ **Semantic Search**: Finds similar tickets by meaning
- ✅ **FAISS**: Fast vector similarity search
- ✅ **Similarity Score**: Returns how similar tickets are

**What it does:**
1. **Build Index**: 
   ```
   Tickets (text) → SentenceTransformer → Embeddings (vectors) → FAISS Index
   ```

2. **Search**:
   ```
   Query (text) → SentenceTransformer → Query Embedding (vector) 
   → FAISS Search → Similar Tickets + Similarity Scores
   ```

3. **Generate Resolution**:
   ```
   Similar Tickets → Groq LLM → AI-generated resolution
   ```

**Does NOT use:**
- ❌ Confidence (that's from Classifier)
- ❌ F1 Score (calculated in app.py)
- ❌ Quality Grade (from Judge)

---

#### **2. GroqTicketClassifier (service/groq_classifier.py)**

**Uses:**
- ✅ **Confidence Score**: AI's certainty about category

**What it does:**
```
Ticket Text → Groq LLM → Category + Confidence + Reasoning
```

**Does NOT use:**
- ❌ Embeddings/Vectors (uses LLM directly, not vector search)
- ❌ FAISS (doesn't need similarity search)
- ❌ Similarity Score (only classifies, doesn't search)
- ❌ F1 Score (calculated later in app.py)

---

#### **3. GroqLLMJudge (service/groq_llm_judge.py)**

**Uses:**
- ✅ **Quality Grade**: A/B/C/D evaluation

**What it does:**
```
Classification/Resolution → Groq LLM Evaluator → Scores (0-1) → Grade (A/B/C/D)
```

**Does NOT use:**
- ❌ Embeddings/Vectors/FAISS (uses LLM for evaluation, not search)
- ❌ Confidence (evaluates confidence, doesn't generate it)
- ❌ F1 Score (provides input scores for F1 calculation)

---

#### **4. GroqAgenticRouter (service/groq_agentic_router.py)**

**Uses:**
- ✅ **Confidence Score**: Input for routing decision
- ✅ **Similarity Score**: Input for routing decision
- ✅ **F1 Score**: Input for routing decision
- ✅ **Quality Grade**: Input for routing decision

**What it does:**
```
All Metrics → Groq LLM Agent → Routing Decision (L1/L2/Manual)
```

**Does NOT use:**
- ❌ Embeddings/Vectors/FAISS (doesn't do search, makes decisions)
- ❌ Sentence Transformation (receives pre-computed scores)

---

#### **5. Flask Application (app.py)**

**Uses:**
- ✅ **F1 Score**: Calculates from confidence + similarity
- ✅ All other metrics: Orchestrates and combines

**What it does:**
```
Orchestrates all components:
1. Classifier → Confidence
2. RAG → Similarity + Resolution
3. Judge → Quality Grade
4. Calculate F1 Score
5. Router → Final Decision
```

---

### **SUMMARY TABLE**

| Concept | RAG System | Classifier | Judge | Agentic Router | Flask App |
|---------|------------|------------|-------|----------------|-----------|
| **Embeddings** | ✅ Creates | ❌ | ❌ | ❌ | ❌ |
| **Sentence Transform** | ✅ Uses | ❌ | ❌ | ❌ | ❌ |
| **Vectors** | ✅ Stores | ❌ | ❌ | ❌ | ❌ |
| **Semantic Search** | ✅ Performs | ❌ | ❌ | ❌ | ❌ |
| **FAISS** | ✅ Uses | ❌ | ❌ | ❌ | ❌ |
| **Similarity Score** | ✅ Generates | ❌ | ❌ | ✅ Uses | ✅ Uses |
| **Confidence Score** | ❌ | ✅ Generates | ✅ Uses | ✅ Uses | ✅ Uses |
| **F1 Score** | ❌ | ❌ | ❌ | ✅ Uses | ✅ Calculates |
| **Quality Grade** | ❌ | ❌ | ✅ Generates | ✅ Uses | ✅ Uses |

---

## **COMPLETE SEQUENCE OF OPERATIONS**

### **STEP-BY-STEP FLOW WITH ALL CONCEPTS**

```
┌────────────────────────────────────────────────────────────┐
│ USER SUBMITS TICKET                                         │
│ Title: "Database connection timeout"                       │
│ Description: "Cannot connect to production SQL server"     │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ STEP 1: CLASSIFICATION (GroqTicketClassifier)              │
├────────────────────────────────────────────────────────────┤
│ Input: Title + Description                                 │
│ Process: Groq LLM analyzes text                           │
│ Output:                                                     │
│   - Category: "Database"                                   │
│   - Confidence: 0.92 ← CONFIDENCE SCORE                   │
│   - Reasoning: "Keywords indicate DB issue"               │
│                                                             │
│ Concept Used: CONFIDENCE SCORE (0-1)                       │
│ Why: Measures AI certainty                                 │
│ Range: 0.92 = 92% sure (High confidence)                  │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ STEP 2: RAG RETRIEVAL (GroqRAGSystem.search_similar)       │
├────────────────────────────────────────────────────────────┤
│ 2A. TEXT TO EMBEDDING                                       │
│ Query: "Database connection timeout..."                    │
│      ↓ [SentenceTransformer.encode()]                     │
│ Query Embedding: [0.23, -0.45, 0.67, ..., 0.12]          │
│                   ↑                                         │
│ Concept: SENTENCE TRANSFORMATION                           │
│ Concept: EMBEDDING (384-dimensional VECTOR)               │
│ Why: Convert text to numbers for comparison                │
│                                                             │
│ 2B. VECTOR SEARCH                                          │
│ Query Vector: [0.23, -0.45, ...]                          │
│      ↓ [FAISS.search()]                                    │
│ Searches 1000 ticket embeddings in FAISS index            │
│      ↓ [Cosine similarity calculation]                     │
│ Finds closest vectors in 384D space                       │
│                                                             │
│ Concept: FAISS (Fast vector search)                       │
│ Concept: SEMANTIC SEARCH (meaning-based)                  │
│ Why: Find similar tickets by meaning, not keywords        │
│                                                             │
│ 2C. RESULTS                                                │
│ Top 3 Similar Tickets:                                     │
│   1. "SQL connection failed" → Similarity: 0.87           │
│   2. "DB timeout error" → Similarity: 0.82                │
│   3. "Database not responding" → Similarity: 0.78         │
│                                                             │
│ Concept: SIMILARITY SCORE (0-1)                            │
│ Why: How close tickets are in vector space                │
│ Range: 0.87 = 87% similar (Very similar)                  │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ STEP 3: RAG GENERATION (GroqRAGSystem.get_resolution)      │
├────────────────────────────────────────────────────────────┤
│ Input: Query + Top 3 similar tickets                       │
│ Process:                                                    │
│   Similar Tickets → Groq LLM → Generate Resolution        │
│                                                             │
│ Output: "Based on similar issues:                          │
│   1. Check connection pool settings                        │
│   2. Verify database server health                         │
│   3. Review network connectivity..."                       │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ STEP 4: QUALITY EVALUATION (GroqLLMJudge)                  │
├────────────────────────────────────────────────────────────┤
│ 4A. EVALUATE CLASSIFICATION                                │
│ Input: Category="Database", Confidence=0.92                │
│ Process: Groq LLM judges quality                           │
│ Scores:                                                     │
│   - Relevance: 0.95 (perfect category match)              │
│   - Accuracy: 0.90 (confidence justified)                  │
│   - Completeness: 0.88 (good reasoning)                    │
│ Overall: (0.95 + 0.90 + 0.88) / 3 = 0.91                  │
│                                                             │
│ 4B. EVALUATE RESOLUTION                                    │
│ Input: Generated resolution text                           │
│ Process: Groq LLM judges quality                           │
│ Scores:                                                     │
│   - Relevance: 0.85 (addresses issue)                      │
│   - Accuracy: 0.82 (technically correct)                   │
│   - Completeness: 0.80 (all steps included)               │
│ Overall: (0.85 + 0.82 + 0.80) / 3 = 0.82                  │
│                                                             │
│ 4C. ASSIGN GRADES                                          │
│ Classification: 0.91 → Grade A ← QUALITY GRADE            │
│ Resolution: 0.82 → Grade B                                 │
│                                                             │
│ Concept: QUALITY GRADE (A/B/C/D)                           │
│ Why: Easy-to-understand quality metric                     │
│ Range: A = 0.90-1.0 (Excellent)                           │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ STEP 5: F1 SCORE CALCULATION (app.py)                      │
├────────────────────────────────────────────────────────────┤
│ Formula: F1 = 2 × (P × R) / (P + R)                       │
│                                                             │
│ Precision (P) = Confidence = 0.92                          │
│ Recall (R) = Avg Similarity = (0.87+0.82+0.78)/3 = 0.82   │
│                                                             │
│ F1 = 2 × (0.92 × 0.82) / (0.92 + 0.82)                    │
│ F1 = 2 × 0.7544 / 1.74                                     │
│ F1 = 0.87 ← F1 SCORE                                       │
│                                                             │
│ Concept: F1 SCORE (0-1)                                    │
│ Why: Balances classification confidence and search quality │
│ Range: 0.87 = 87% (Very Good)                             │
│                                                             │
│ Interpretation:                                             │
│ - High confidence (0.92) ✓                                 │
│ - Good similarity (0.82) ✓                                 │
│ - Balanced F1 (0.87) ✓                                     │
│ → Reliable prediction                                      │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ STEP 6: AGENTIC ROUTING (GroqAgenticRouter)                │
├────────────────────────────────────────────────────────────┤
│ Input Metrics:                                              │
│   - Category: Database                                     │
│   - Confidence: 0.92                                       │
│   - Similarity: 0.87, 0.82, 0.78                          │
│   - Classification Grade: A                                │
│   - Resolution Grade: B                                    │
│   - F1 Score: 0.87                                         │
│                                                             │
│ Process: Groq LLM Agent analyzes ALL metrics              │
│                                                             │
│ AI Reasoning:                                              │
│ "High confidence (0.92) indicates clear classification.    │
│  Excellent similarity (0.87) shows strong historical      │
│  matches. F1 score (0.87) is very good. Quality grades   │
│  are A/B indicating reliable output. Category is Database │
│  (not critical security). Suitable for L1 Support."       │
│                                                             │
│ Decision:                                                   │
│   - Level: L1 Support                                      │
│   - Team: Database Support Team                            │
│   - Priority: Medium                                       │
│   - Estimated Time: 2 hours                                │
│   - Auto-resolve: Possible                                 │
│                                                             │
│ Concepts Used:                                             │
│ - CONFIDENCE, SIMILARITY, F1, QUALITY GRADE (all as input)│
│ Why: Intelligent routing considers ALL factors            │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ STEP 7: RESPONSE TO USER                                   │
├────────────────────────────────────────────────────────────┤
│ Complete AI Response:                                       │
│                                                             │
│ ✅ Resolution: "Based on similar issues..."                │
│ ✅ Category: Database (Confidence: 92%)                    │
│ ✅ Similar Tickets: 3 found (87% similarity)               │
│ ✅ Quality: Classification A, Resolution B                 │
│ ✅ F1 Score: 0.87 (Very Good)                              │
│ ✅ Routing: L1 Support - Database Team                     │
│ ✅ Estimated Time: 2 hours                                 │
└────────────────────────────────────────────────────────────┘
```

---

### **WHY EACH SCORE RANGE IS 0-1**

#### **1. Mathematical Reasons:**

**Probabilities:**
- Confidence is a probability: P(category | text)
- Must be between 0 and 1 (0% to 100%)
- Sum of all category probabilities = 1.0

**Cosine Similarity:**
- Measures angle between vectors
- Normalized: result is [-1, 1]
- With normalized embeddings: result is [0, 1]
- 1.0 = same direction (identical)
- 0.0 = perpendicular (unrelated)

**F1 Score:**
- Harmonic mean of precision and recall
- Both in [0, 1], so F1 also in [0, 1]
- Standard metric in ML/AI

#### **2. Practical Reasons:**

**Easy to Understand:**
```
0.0 = 0% = Nothing
0.5 = 50% = Half/Medium
1.0 = 100% = Perfect/Complete
```

**Easy to Compare:**
```
Confidence: 0.92 > 0.85 (better)
Similarity: 0.75 > 0.45 (more similar)
F1: 0.80 > 0.60 (higher quality)
```

**Standard Scale:**
- Used across all ML/AI systems
- Easy to set thresholds (e.g., "require confidence > 0.7")
- Percentage interpretation (0.85 = 85%)

#### **3. Why NOT Other Ranges?**

**Why not 0-100?**
- Mathematically: Probabilities are 0-1
- Programming: Float division, no rounding needed
- Convention: ML/AI standard is 0-1

**Why not 1-10?**
- Less precision (only 10 values vs infinite)
- Not probability-based
- Harder math (8/10 vs 0.8)

**Why not -1 to 1?**
- Negative confidence doesn't make sense
- We normalize embeddings, so similarity ≥ 0
- Harder to interpret (is -0.5 bad or medium?)

---

## **CONCEPT INTERACTION MAP**

### **How Concepts Work Together**

```
┌─────────────────────────────────────────────────────────┐
│                    USER TICKET                           │
│              "Database timeout error"                    │
└────────────────┬────────────────────────────────────────┘
                 │
    ┌────────────┴────────────┐
    │                         │
    ▼                         ▼
┌─────────┐           ┌──────────────┐
│ TEXT    │           │    TEXT      │
│ ONLY    │           │    ONLY      │
└────┬────┘           └──────┬───────┘
     │                       │
     │ Classifier            │ RAG System
     │ (No vectors)          │ (Needs vectors)
     │                       │
     ▼                       ▼
┌──────────────┐    ┌─────────────────────────┐
│ Groq LLM     │    │ SENTENCE TRANSFORMER    │
│ Analysis     │    │ "DB timeout error"      │
│              │    │         ↓               │
│ Returns:     │    │ EMBEDDING               │
│ - Category   │    │ [0.2, -0.4, ..., 0.1]  │
│ - CONFIDENCE │    │         ↓               │
│   0.92       │    │ VECTOR (384D)           │
└──────┬───────┘    └──────┬──────────────────┘
       │                   │
       │                   ▼
       │            ┌─────────────────┐
       │            │ FAISS INDEX     │
       │            │ Search vectors  │
       │            │ SEMANTIC SEARCH │
       │            │        ↓        │
       │            │ SIMILARITY      │
       │            │ Scores: 0.87,   │
       │            │ 0.82, 0.78      │
       │            └────────┬────────┘
       │                     │
       └──────┬──────────────┘
              │
              ▼
    ┌──────────────────────┐
    │  COMBINE METRICS     │
    │                      │
    │ Confidence: 0.92     │
    │ Similarity: 0.82 avg │
    │         ↓            │
    │  F1 SCORE            │
    │  = 2×(0.92×0.82)     │
    │    /(0.92+0.82)      │
    │  = 0.87              │
    └──────────┬───────────┘
               │
               ▼
    ┌──────────────────────┐
    │  LLM JUDGE           │
    │  Evaluates quality   │
    │         ↓            │
    │  QUALITY GRADE       │
    │  A/B/C/D             │
    └──────────┬───────────┘
               │
               ▼
    ┌──────────────────────┐
    │  AGENTIC ROUTER      │
    │  Uses ALL metrics:   │
    │  - Confidence        │
    │  - Similarity        │
    │  - F1 Score          │
    │  - Quality Grade     │
    │         ↓            │
    │  ROUTING DECISION    │
    │  L1/L2/Manual        │
    └──────────────────────┘
```

---

## **PRACTICAL EXAMPLES**

### **Example 1: Perfect Case**

```
Ticket: "SQL database connection pool exhausted"

STEP 1 - Classification:
  Groq LLM → Category: Database
  CONFIDENCE: 0.95 (very clear keywords)

STEP 2 - Embedding:
  SentenceTransformer → [0.71, -0.23, 0.58, ...]
  VECTOR in 384D space

STEP 3 - FAISS Search:
  SEMANTIC SEARCH finds:
  1. "DB connection pool timeout" - SIMILARITY: 0.92
  2. "Database pool size exceeded" - SIMILARITY: 0.89
  3. "SQL connection limit reached" - SIMILARITY: 0.87

STEP 4 - F1 Calculation:
  Precision = CONFIDENCE = 0.95
  Recall = Avg SIMILARITY = 0.89
  F1 = 2 × (0.95 × 0.89) / (0.95 + 0.89) = 0.92

STEP 5 - Quality Grade:
  LLM Judge → Classification: A, Resolution: A
  QUALITY GRADE: Excellent

STEP 6 - Routing:
  All metrics excellent → L1 Support
  Auto-resolve possible
```

### **Example 2: Uncertain Case**

```
Ticket: "System slow"

STEP 1 - Classification:
  Groq LLM → Category: Infrastructure (guessing)
  CONFIDENCE: 0.55 (vague description)

STEP 2 - Embedding:
  SentenceTransformer → [0.12, 0.08, -0.31, ...]
  VECTOR in 384D space

STEP 3 - FAISS Search:
  SEMANTIC SEARCH finds:
  1. "Server performance degraded" - SIMILARITY: 0.48
  2. "Network latency high" - SIMILARITY: 0.42
  3. "Application response slow" - SIMILARITY: 0.40
  (Multiple categories mixed)

STEP 4 - F1 Calculation:
  Precision = CONFIDENCE = 0.55
  Recall = Avg SIMILARITY = 0.43
  F1 = 2 × (0.55 × 0.43) / (0.55 + 0.43) = 0.48

STEP 5 - Quality Grade:
  LLM Judge → Classification: C, Resolution: C
  QUALITY GRADE: Needs review

STEP 6 - Routing:
  Low metrics → Manual Review Required
  Need more information
```

### **Example 3: New Issue Type**

```
Ticket: "Quantum processor decoherence in cluster"

STEP 1 - Classification:
  Groq LLM → Category: Infrastructure (uncertain)
  CONFIDENCE: 0.60 (unfamiliar terminology)

STEP 2 - Embedding:
  SentenceTransformer → [0.33, -0.12, 0.67, ...]
  VECTOR in 384D space

STEP 3 - FAISS Search:
  SEMANTIC SEARCH finds:
  1. "Cluster node failure" - SIMILARITY: 0.35
  2. "Hardware malfunction" - SIMILARITY: 0.32
  3. "System instability" - SIMILARITY: 0.28
  (Low similarity - no similar historical tickets!)

STEP 4 - F1 Calculation:
  Precision = CONFIDENCE = 0.60
  Recall = Avg SIMILARITY = 0.32
  F1 = 2 × (0.60 × 0.32) / (0.60 + 0.32) = 0.42

STEP 5 - Quality Grade:
  LLM Judge → Classification: C, Resolution: D
  QUALITY GRADE: Poor quality

STEP 6 - Routing:
  Low F1 + Low similarity = NEW ISSUE TYPE
  → Manual Review by Senior Engineer
  → Potentially create new category
```

---

## **KEY TAKEAWAYS**

### **1. All Concepts Serve Different Purposes**

- **Embeddings/Vectors**: Enable semantic comparison
- **FAISS**: Makes search fast
- **Sentence Transformer**: Converts text → vectors
- **Semantic Search**: Finds meaning, not keywords
- **Confidence**: How sure AI is
- **Similarity**: How close tickets are
- **F1 Score**: Combined quality metric
- **Quality Grade**: Human-readable assessment

### **2. RAG System is About Search**

RAG ONLY uses:
- ✅ Embeddings
- ✅ Vectors
- ✅ FAISS
- ✅ Semantic Search
- ✅ Generates Similarity Scores

Purpose: **Find similar tickets, generate resolutions**

### **3. Agentic Router is About Decisions**

Agentic Router ONLY uses:
- ✅ Confidence (from Classifier)
- ✅ Similarity (from RAG)
- ✅ F1 Score (from Flask)
- ✅ Quality Grade (from Judge)

Purpose: **Make routing decisions based on metrics**

### **4. Why 0-1 Range Everywhere**

- **Mathematical**: Standard for probabilities and similarities
- **Practical**: Easy to understand (percentage)
- **Comparable**: All metrics on same scale
- **Threshold-friendly**: "If > 0.7, then approve"

### **5. Each Component Has Clear Role**

```
Classifier → Categorizes (Confidence)
RAG → Searches & Generates (Similarity, Embeddings)
Judge → Evaluates (Quality Grade)
Router → Decides (Uses all metrics)
Flask → Orchestrates (Calculates F1, combines all)
```

No overlap, clear separation of concerns!

---

## **CONCLUSION**

This system combines multiple AI/ML concepts:

1. **NLP (Natural Language Processing)**: Understanding text
2. **Vector Embeddings**: Representing text as numbers
3. **Similarity Search**: Finding related content
4. **LLM (Large Language Models)**: Intelligent analysis
5. **Machine Learning Metrics**: Quality assessment
6. **Agentic AI**: Autonomous decision-making

All working together to create an intelligent ticket routing system that's:
- **Fast** (FAISS search)
- **Accurate** (Semantic understanding)
- **Reliable** (Multiple quality checks)
- **Explainable** (Every decision has metrics)
