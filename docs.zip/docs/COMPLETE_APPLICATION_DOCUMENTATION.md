# AI Ticket Routing System - Complete Documentation

## **TABLE OF CONTENTS**
1. [System Overview](#system-overview)
2. [Architecture & Design](#architecture--design)
3. [Core Components](#core-components)
4. [Application Flow](#application-flow)
5. [Technical Details](#technical-details)
6. [Why This Design](#why-this-design)

---

## **SYSTEM OVERVIEW**

### **What This Application Does**
An AI-powered IT support ticket routing system that automatically:
- **Classifies** incoming support tickets into categories
- **Finds** similar historical tickets using vector search
- **Generates** intelligent resolution suggestions using AI
- **Routes** tickets to appropriate support teams with priority levels
- **Evaluates** quality of classifications and resolutions

### **Technologies Used**
- **Backend**: Flask (Python web framework)
- **AI/ML**: Groq LLM (Meta Llama 3.3 70B), LangChain
- **Vector Search**: FAISS (Facebook AI Similarity Search)
- **Embeddings**: Sentence Transformers (all-MiniLM-L6-v2)
- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Data**: Pandas, NumPy, Pickle

---

## **ARCHITECTURE & DESIGN**

### **System Architecture**
```
┌─────────────────────────────────────────────────────────────┐
│                         USER                                 │
│                    (Web Browser)                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                  FRONTEND (chatbot.html)                     │
│  - User Interface                                            │
│  - Sends POST /chat requests                                 │
│  - Displays AI responses                                     │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   FLASK SERVER (app.py)                      │
│  - Route handling (/chat, /classify, /similar, etc.)        │
│  - Request orchestration                                     │
│  - Response formatting                                       │
└────────────┬───────────┬──────────┬──────────┬──────────────┘
             │           │          │          │
             ▼           ▼          ▼          ▼
   ┌────────────┐ ┌──────────┐ ┌────────┐ ┌──────────────┐
   │ Classifier │ │   RAG    │ │ Judge  │ │    Router    │
   │  (Groq)    │ │ (FAISS+  │ │ (Groq) │ │    (Groq)    │
   │            │ │   Groq)  │ │        │ │              │
   └────────────┘ └──────────┘ └────────┘ └──────────────┘
                       │
                       ▼
              ┌─────────────────┐
              │  FAISS Index    │
              │  (Vector DB)    │
              │  1000+ tickets  │
              └─────────────────┘
```

### **Data Flow**
```
User Message → Flask → Classifier → Category + Confidence
                  ↓
              RAG System → Search FAISS → Find Similar Tickets
                  ↓
              Groq LLM → Generate Resolution
                  ↓
              LLM Judge → Evaluate Quality → A/B/C/D Grade
                  ↓
              Calculate F1 Score → Precision × Recall
                  ↓
              Agentic Router → Assign Team → L1/L2/Manual
                  ↓
              Response to User
```

---

## **CORE COMPONENTS**

### **1. GroqTicketClassifier (service/groq_classifier.py)**

**Purpose**: Classifies support tickets into 6 categories using AI

**Categories:**
1. Infrastructure (servers, hardware, CPU, memory)
2. Database (SQL, queries, backups, connections)
3. Security (breaches, malware, firewall)
4. Network (connectivity, DNS, routers)
5. Access Management (passwords, login, MFA)
6. Application (software bugs, features)

**How It Works:**
1. Receives: ticket title + description
2. Sends to Groq LLM with classification prompt
3. LLM analyzes and returns:
   - Predicted category
   - Confidence score (0-1)
   - Reasoning explanation
   - Scores for all categories

**Why Use Groq LLM?**
- **Accurate**: Better than keyword matching
- **Context-aware**: Understands nuances
- **Explainable**: Provides reasoning
- **Fast**: Groq inference is very fast

**Fallback**: If API fails, uses keyword matching

**Example:**
```python
Input: "Database timeout errors in production"
Output: {
    'category': 'Database',
    'confidence': 0.92,
    'reasoning': 'Keywords indicate database performance issue'
}
```

---

### **2. GroqRAGSystem (service/groq_rag_system.py)**

**Purpose**: Retrieval-Augmented Generation - Finds similar tickets and generates resolutions

**What is RAG?**
- **Retrieval**: Search historical tickets using vector similarity
- **Augmentation**: Use past tickets as context
- **Generation**: AI creates resolution based on history

**Components:**

#### **A. Embedding Model (SentenceTransformer)**
- **Purpose**: Converts text to 384-dimensional vectors
- **Model**: `sentence-transformers/all-MiniLM-L6-v2`
- **Why**: Enables semantic similarity search
- **Cached**: Stored in `models_cache/` for fast loading

#### **B. FAISS Index**
- **Purpose**: Fast vector similarity search
- **Type**: IndexFlatIP (Inner Product - cosine similarity)
- **Size**: 1000+ ticket embeddings
- **Speed**: Searches millions of vectors in milliseconds

#### **C. Groq LLM**
- **Purpose**: Generates resolution from similar tickets
- **Model**: `llama-3.3-70b-versatile`
- **Input**: Query + 3 most similar tickets
- **Output**: Detailed resolution steps

**How It Works:**
1. **Build Index** (first run only):
   - Reads `synthetic_tickets_dataset.csv`
   - Generates embeddings for all tickets
   - Builds FAISS index
   - Saves to disk (`data/faiss/`)

2. **Search Similar** (every query):
   - Converts query to embedding
   - Searches FAISS index
   - Returns top K similar tickets with scores

3. **Generate Resolution**:
   - Takes similar tickets as context
   - Sends to Groq LLM with RAG prompt
   - LLM synthesizes resolution from patterns

**Why Use FAISS?**
- **Fast**: Millisecond search vs. seconds with brute force
- **Scalable**: Handles millions of vectors
- **Persistent**: Cached to disk, instant reload

**Why Use RAG?**
- **Grounded**: Based on real historical data
- **Accurate**: LLM doesn't hallucinate
- **Contextual**: Considers past solutions

**Example:**
```python
Input: "Database connection timeout"
FAISS Search: Finds 3 similar tickets (similarity: 0.85, 0.82, 0.78)
LLM Generation: "Based on similar issues, try:
  1. Check connection pool settings
  2. Verify database server health
  3. Review network connectivity..."
```

---

### **3. GroqLLMJudge (service/groq_llm_judge.py)**

**Purpose**: LLM-as-Judge pattern - Evaluates quality of classifications and resolutions

**What It Evaluates:**

#### **Classification Quality:**
- **Relevance**: Does category match ticket content? (0-1)
- **Accuracy**: Is confidence score appropriate? (0-1)
- **Completeness**: Does reasoning make sense? (0-1)
- **Overall**: Average score

#### **Resolution Quality:**
- **Relevance**: Does it address the issue? (0-1)
- **Accuracy**: Are steps technically correct? (0-1)
- **Completeness**: All necessary steps included? (0-1)
- **Overall**: Average score

**How It Works:**
1. Sends classification/resolution to Groq LLM
2. LLM acts as expert evaluator
3. Parses scores from LLM response
4. Returns structured evaluation

**Why Use LLM as Judge?**
- **Objective**: Consistent evaluation criteria
- **Intelligent**: Understands context
- **Automated**: No manual review needed
- **Continuous**: Monitors quality in real-time

**Quality Grades:**
- **A**: Score ≥ 0.90 (Excellent)
- **B**: Score ≥ 0.75 (Good)
- **C**: Score ≥ 0.60 (Acceptable)
- **D**: Score < 0.60 (Poor - needs review)

---

### **4. GroqAgenticRouter (service/groq_agentic_router.py)**

**Purpose**: AI agent that makes intelligent routing decisions for tickets

**What is Agentic AI?**
- **Autonomous**: Makes decisions based on reasoning
- **Context-aware**: Considers multiple factors
- **Explainable**: Provides detailed reasoning
- **Adaptive**: Learns patterns from metrics

**Routing Levels:**
- **L1 Support**: Simple issues, high confidence, auto-resolvable
- **L2 Support**: Medium complexity, experienced engineers needed
- **Manual Review**: Complex/novel/critical, senior expert needed

**Decision Factors:**
1. **Classification Confidence** (0-1)
2. **Quality Grade** (A/B/C/D)
3. **F1 Score** (balance of precision/recall)
4. **Similarity to Historical Tickets** (0-1)
5. **Category** (Security → higher priority)
6. **New Category Flag** (unseen issues → manual review)

**How It Works:**
1. Receives all metrics from previous steps
2. Sends comprehensive analysis request to Groq LLM
3. LLM reasons about:
   - Complexity level
   - Required expertise
   - Urgency/priority
   - Escalation needs
4. Returns structured decision with:
   - Routing level
   - Team assignment
   - Priority adjustment
   - Estimated resolution time
   - Recommended actions
   - Detailed reasoning

**Why Use Agentic Router?**
- **Intelligent**: Better than simple rules
- **Nuanced**: Considers multiple factors
- **Explainable**: Shows reasoning
- **Dynamic**: Adapts to metrics

**Example Decision:**
```
Input Metrics:
  - Confidence: 0.65
  - Quality Grade: C
  - F1 Score: 0.58
  - Similarity: 0.45
  - Category: Security

LLM Decision:
  - Level: Manual Review Required
  - Team: Security Operations Center
  - Priority: Escalate
  - Reasoning: "Low similarity and security category requires expert review"
  - Actions: ["Immediate senior review", "Check security logs", "Verify no breach"]
```

---

### **5. Flask Application (app.py)**

**Purpose**: Web server that orchestrates all components

**Key Endpoints:**

#### **POST /chat** (Main endpoint)
**Flow:**
1. Classify ticket → `classifier.predict()`
2. Search similar → `rag_system.get_resolution_with_llm()`
3. Evaluate classification → `judge.evaluate_classification()`
4. Evaluate resolution → `judge.evaluate_resolution()`
5. Calculate F1 score → `calculate_f1_score()`
6. Route ticket → `agentic_router.route_ticket()`
7. Return complete response

**Response Includes:**
- AI-generated resolution
- Classification (category, confidence)
- Similar tickets (top 3)
- Quality scores (A/B/C/D grade)
- Team assignment
- Estimated time

#### **Other Endpoints:**
- **GET /** → Serves chatbot UI
- **POST /classify** → Classification only
- **POST /similar** → Find similar tickets
- **GET /stats** → Database statistics
- **GET /all_tickets** → All historical tickets
- **GET /new_tickets** → Analyze incoming tickets
- **GET /health** → System health check

---

## **APPLICATION FLOW**

### **Complete User Request Flow**

```
Step 1: User Types Message
  ↓
Step 2: Frontend sends POST /chat
  ↓
Step 3: CLASSIFICATION
  - classifier.predict()
  - Input: title, description
  - Output: category, confidence, reasoning
  - Time: ~500ms
  ↓
Step 4: RAG RETRIEVAL
  - rag_system.search_similar()
  - FAISS search for similar tickets
  - Time: ~50ms
  ↓
Step 5: RAG GENERATION
  - rag_system.get_resolution_with_llm()
  - Groq LLM generates resolution from similar tickets
  - Time: ~1000ms
  ↓
Step 6: QUALITY EVALUATION
  - judge.evaluate_classification()
  - judge.evaluate_resolution()
  - LLM scores both outputs
  - Time: ~800ms
  ↓
Step 7: METRICS CALCULATION
  - calculate_f1_score()
  - F1 = 2 * (precision * recall) / (precision + recall)
  - Quality grade: A/B/C/D
  - Time: <1ms
  ↓
Step 8: AGENTIC ROUTING
  - agentic_router.route_ticket()
  - LLM analyzes all metrics
  - Decides: L1/L2/Manual, team, priority
  - Time: ~1000ms
  ↓
Step 9: RESPONSE ASSEMBLY
  - Combine all results
  - Convert numpy types to JSON
  - Format response
  - Time: <10ms
  ↓
Step 10: RETURN TO USER
  - JSON response with complete analysis
  - Total time: ~3-4 seconds

Frontend: Display formatted response with:
  - AI resolution
  - Category badge
  - Confidence meter
  - Similar tickets
  - Quality grade
  - Team assignment
```

---

## **TECHNICAL DETAILS**

### **FAISS Indexing Process**

#### **First Run (No Cache):**
```
1. initialize_system() called
2. rag_system.build_index(csv_path) called
3. load_index() checks data/faiss/ → NOT FOUND
4. Read CSV: pd.read_csv() → 1000 tickets
5. Generate embeddings:
   - SentenceTransformer.encode()
   - 1000 tickets × 384 dimensions
   - Time: ~10-15 seconds
6. Build FAISS index:
   - faiss.IndexFlatIP(384)
   - index.add(embeddings)
   - Time: ~100ms
7. Save to disk:
   - ticket_embeddings.index (FAISS)
   - embeddings.npy (NumPy)
   - ticket_data.pkl (Pickle)
   - Time: ~500ms
Total: ~10-20 seconds
```

#### **Subsequent Runs (Cache Exists):**
```
1. initialize_system() called
2. rag_system.build_index(csv_path) called
3. load_index() checks data/faiss/ → FOUND!
4. Load from disk:
   - faiss.read_index() → index
   - np.load() → embeddings
   - pickle.load() → ticket_data
   - Time: ~1-2 seconds
Total: ~1-2 seconds (10x faster!)
```

### **Embedding Model Caching**
```
First Run:
  - Downloads model from HuggingFace
  - Saves to models_cache/
  - Time: ~30-60 seconds (one-time)

Subsequent Runs:
  - Loads from models_cache/
  - Time: ~2-3 seconds
```

### **F1 Score Calculation**
```python
def calculate_f1_score(confidence, category, similar_tickets):
    # Precision = Classification confidence
    precision = confidence
    
    # Recall = Average similarity of top-3 tickets
    if similar_tickets:
        avg_similarity = sum(t['similarity'] for t in similar_tickets[:3]) / 3
        recall = avg_similarity
    else:
        recall = 0.3  # Low recall if no similar tickets
    
    # F1 = Harmonic mean of precision and recall
    if precision + recall > 0:
        f1_score = 2 * (precision * recall) / (precision + recall)
    else:
        f1_score = 0.0
    
    return f1_score
```

**Why F1 Score?**
- **Balanced metric**: Considers both precision and recall
- **Single number**: Easy to interpret (0-1 scale)
- **Quality indicator**: Low F1 → poor confidence or low similarity → needs manual review

---

## **WHY THIS DESIGN**

### **1. Why Use Multiple AI Components?**

**Problem**: A single AI model can't handle all aspects well

**Solution**: Specialized components for different tasks

| Component | Purpose | Why Separate |
|-----------|---------|--------------|
| Classifier | Categorize tickets | Focused on classification only, fast |
| RAG System | Find similar + generate | Needs vector search + LLM generation |
| LLM Judge | Evaluate quality | Independent assessment, no bias |
| Agentic Router | Smart routing | Complex decision-making with reasoning |

**Benefits:**
- **Modularity**: Each component can be upgraded independently
- **Reliability**: If one fails, others still work (fallbacks)
- **Clarity**: Single responsibility principle
- **Performance**: Optimized for specific tasks

---

### **2. Why Use FAISS Instead of Database?**

**Traditional Database Search:**
```sql
SELECT * FROM tickets WHERE description LIKE '%database%timeout%'
```
**Problems:**
- Only finds exact keyword matches
- Misses semantic similarity ("DB connection slow" vs "database timeout")
- Slow on large datasets

**FAISS Vector Search:**
```python
query_embedding = model.encode("database timeout")
similar = index.search(query_embedding, top_k=5)
```
**Benefits:**
- **Semantic**: Understands meaning, not just keywords
- **Fast**: Milliseconds for millions of vectors
- **Accurate**: Finds conceptually similar tickets
- **Scalable**: Handles growing datasets efficiently

**Example:**
```
Query: "Cannot access email"

Database: Finds tickets with words "cannot", "access", "email"
FAISS: Finds "Login issues with Outlook", "Mail server down", "Email authentication failed"
```

---

### **3. Why Use Groq Instead of OpenAI/Other LLMs?**

**Groq Advantages:**
- **Speed**: 10x faster inference than standard LLMs
- **Cost**: More affordable API pricing
- **Quality**: Meta Llama 3.3 70B is highly capable
- **Free tier**: Allows development without costs

**Speed Comparison:**
| Provider | Response Time | Cost/1M Tokens |
|----------|--------------|----------------|
| Groq (Llama 3.3 70B) | ~500ms | $0.59 |
| OpenAI (GPT-4) | ~2000ms | $30.00 |
| Claude (Anthropic) | ~1500ms | $15.00 |

**Why Speed Matters:**
- User experience: 3s total response vs 10s+
- Concurrent users: Handle more requests
- Multiple LLM calls: Classifier + RAG + Judge + Router = 4 calls per request

---

### **4. Why Use LLM-as-Judge Pattern?**

**Alternative**: Manual quality review

**Problems:**
- Time-consuming
- Inconsistent
- Not scalable
- Expensive

**LLM-as-Judge Solution:**
- **Automated**: Every response evaluated
- **Consistent**: Same criteria every time
- **Scalable**: Handles unlimited volume
- **Fast**: Real-time evaluation
- **Detailed**: Provides scores + feedback

**Use Cases:**
- Monitor system quality in production
- Identify low-quality responses
- Trigger manual review when needed
- Track quality metrics over time

---

### **5. Why Agentic Router Over Rule-Based?**

**Rule-Based Routing:**
```python
if confidence > 0.8:
    return "L1 Support"
elif confidence > 0.6:
    return "L2 Support"
else:
    return "Manual Review"
```

**Problems:**
- **Rigid**: Can't handle edge cases
- **Simple**: Only considers one metric
- **Not adaptive**: Fixed rules don't improve

**Agentic AI Routing:**
```python
# AI considers ALL factors:
# - Confidence, quality grade, F1 score
# - Similarity, category, new category flag
# - Context, urgency, complexity
# → Makes nuanced decision with reasoning
```

**Benefits:**
- **Intelligent**: Considers multiple factors
- **Nuanced**: Handles complex scenarios
- **Explainable**: Provides reasoning
- **Adaptive**: Can improve with feedback

**Example:**
```
Ticket: "Security breach - production database accessed"

Rule-based: Confidence = 0.85 → L1 Support ❌ (Wrong!)

Agentic AI: 
  - High confidence BUT security category
  - Critical keyword: "breach"
  - Production environment
  → Manual Review + Immediate escalation ✓ (Correct!)
```

---

### **6. Why Separate Frontend & Backend?**

**Architecture:**
```
Frontend (HTML/CSS/JS) ←→ Backend (Flask/Python) ←→ AI Services
```

**Benefits:**
- **Separation of concerns**: UI vs. business logic
- **API-first**: Can add mobile app, CLI, other frontends
- **Scalability**: Frontend and backend can scale independently
- **Development**: Frontend and backend teams can work separately
- **Testing**: Easier to test API endpoints

---

### **7. Why Cache Everything?**

**What's Cached:**
1. **Embedding Model** → `models_cache/`
2. **FAISS Index** → `data/faiss/`
3. **Ticket Data** → `data/faiss/ticket_data.pkl`

**Benefits:**
- **Faster startup**: 1-2s vs 30-60s
- **Offline capable**: Works without internet (after first run)
- **Reduced API calls**: No re-downloading models
- **Cost savings**: Less bandwidth usage

**Startup Time Comparison:**
| Scenario | Time | Notes |
|----------|------|-------|
| First ever run | ~60s | Download model + build index |
| First run (model cached) | ~15s | Build index only |
| Subsequent runs | ~2s | Load everything from cache |

---

### **8. Why This Tech Stack?**

**Backend: Flask**
- **Simple**: Easy to understand and maintain
- **Lightweight**: No unnecessary features
- **Python**: Same language as AI/ML libraries
- **Fast development**: Quick prototyping

**AI: Groq + LangChain**
- **Groq**: Fast, affordable LLM inference
- **LangChain**: Standard framework for LLM apps
- **Structured outputs**: Pydantic models ensure consistency

**Search: FAISS**
- **Industry standard**: Battle-tested by Facebook
- **Performance**: Optimized C++ implementation
- **Scalable**: Handles billions of vectors
- **Flexible**: Multiple index types

**Embeddings: Sentence Transformers**
- **Quality**: State-of-the-art semantic embeddings
- **Size**: 384 dimensions (good balance)
- **Speed**: Fast inference
- **Free**: No API costs

---

## **SYSTEM BENEFITS**

### **For Support Teams:**
1. **Faster resolutions**: AI suggests solutions from past tickets
2. **Accurate routing**: Right team gets ticket first time
3. **Quality assurance**: LLM Judge monitors every response
4. **Knowledge retention**: Past solutions never lost

### **For Users:**
1. **Quick responses**: 3-4 second AI analysis
2. **Accurate answers**: Based on real historical data
3. **Consistent quality**: LLM-as-Judge ensures high standards
4. **24/7 availability**: AI works around the clock

### **For Organization:**
1. **Cost reduction**: Fewer escalations, faster resolutions
2. **Scalability**: Handles unlimited ticket volume
3. **Insights**: Quality metrics, category trends
4. **Continuous improvement**: Learn from every ticket

---

## **FUTURE ENHANCEMENTS**

### **Potential Improvements:**
1. **Multi-language support**: Classify tickets in any language
2. **Real-time learning**: Update FAISS index with new resolutions
3. **Priority prediction**: AI predicts urgency automatically
4. **SLA tracking**: Estimate and track resolution SLAs
5. **Team workload**: Balance ticket distribution
6. **Customer satisfaction**: Predict CSAT scores
7. **Root cause analysis**: Identify recurring issues

---

## **CONCLUSION**

This AI-powered ticket routing system combines modern ML techniques:
- **Classification**: Groq LLM for accurate categorization
- **RAG**: FAISS + Groq for intelligent resolution suggestions
- **Quality**: LLM-as-Judge for continuous monitoring
- **Routing**: Agentic AI for smart team assignment

**Key Strengths:**
✅ **Fast**: 3-4 second end-to-end response
✅ **Accurate**: Based on 1000+ historical tickets
✅ **Intelligent**: Multiple AI agents working together
✅ **Scalable**: FAISS handles millions of tickets
✅ **Reliable**: Fallbacks for every component
✅ **Explainable**: Every decision has reasoning

**Result**: A production-ready AI system that improves support efficiency, quality, and user satisfaction.
