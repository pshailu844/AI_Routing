# Configuration Changes Summary

## Overview

All model names are now configurable via environment variables instead of being hardcoded in Python files.

## Changes Made

### 1. Environment Files Updated

#### `.env.example`
```env
# Groq API Configuration
GROQ_API_KEY=your_groq_api_key_here

# Get your API key from: https://console.groq.com/keys
# Free tier available with generous limits

# Model Configuration
GROQ_MODEL=llama-3.3-70b-versatile
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
```

#### `.env`
```env
# Groq API Configuration
GROQ_API_KEY=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

# Get your API key from: https://console.groq.com/keys
# Free tier available with generous limits

# Model Configuration
GROQ_MODEL=llama-3.3-70b-versatile
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
```

### 2. Service Files Updated

#### `service/groq_classifier.py`

**Before:**
```python
def __init__(self, model_name: str = "llama-3.3-70b-versatile"):
    self.model_name = model_name
    # ...
    self.llm = ChatGroq(model=model_name, ...)
```

**After:**
```python
def __init__(self, model_name: Optional[str] = None):
    # Use environment variable or provided model_name or default
    self.model_name = model_name or os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    # ...
    self.llm = ChatGroq(model=self.model_name, ...)
```

#### `service/groq_rag_system.py`

**Before:**
```python
def __init__(
    self, 
    embedding_model: str = 'all-MiniLM-L6-v2',
    llm_model: str = "llama-3.3-70b-versatile"
):
    self.embedding_model_name = embedding_model
    self.llm_model_name = llm_model
    # ...
    self.embedding_model = SentenceTransformer(embedding_model)
    self.llm = ChatGroq(model=llm_model, ...)
```

**After:**
```python
def __init__(
    self, 
    embedding_model: Optional[str] = None,
    llm_model: Optional[str] = None
):
    # Use environment variables or provided parameters or defaults
    self.embedding_model_name = embedding_model or os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    self.llm_model_name = llm_model or os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    # ...
    self.embedding_model = SentenceTransformer(self.embedding_model_name)
    self.llm = ChatGroq(model=self.llm_model_name, ...)
```

#### `service/groq_llm_judge.py`

**Before:**
```python
from typing import Dict, List

def __init__(self, model_name: str = "llama-3.3-70b-versatile"):
    # ...
    self.llm = ChatGroq(model=model_name, ...)
```

**After:**
```python
from typing import Dict, List, Optional

def __init__(self, model_name: Optional[str] = None):
    # Use environment variable or provided model_name or default
    self.model_name = model_name or os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    # ...
    self.llm = ChatGroq(model=self.model_name, ...)
```

### 3. Documentation Added

- **`docs/CONFIGURATION_GUIDE.md`** - Complete guide on model configuration
- **`README.md`** - Updated with configuration instructions

## Benefits

### Before (Hardcoded)
❌ Must edit Python files to change models  
❌ Models scattered across multiple files  
❌ Risk of inconsistent model versions  
❌ Requires code changes for dev/prod differences  

### After (Environment Variables)
✅ Change models via `.env` file only  
✅ Centralized configuration  
✅ Consistent model versions across all services  
✅ Easy dev/prod environment switching  
✅ No code changes needed  
✅ Secure (API keys in `.env`, not code)  

## Usage Examples

### Default Usage (Reads from .env)
```python
from service.groq_classifier import GroqTicketClassifier
from service.groq_rag_system import GroqRAGSystem
from service.groq_llm_judge import GroqLLMJudge

# All read from environment variables
classifier = GroqTicketClassifier()
rag = GroqRAGSystem()
judge = GroqLLMJudge()
```

### Override if Needed
```python
# Override specific models
classifier = GroqTicketClassifier(model_name="llama-3.1-8b-instant")
rag = GroqRAGSystem(
    embedding_model="sentence-transformers/all-mpnet-base-v2",
    llm_model="mixtral-8x7b-32768"
)
judge = GroqLLMJudge(model_name="gemma2-9b-it")
```

## Environment Variable Priority

For each service, the priority order is:
1. **Explicitly provided parameter** (if passed to `__init__`)
2. **Environment variable** (from `.env` file)
3. **Default hardcoded value** (fallback)

Example for `GROQ_MODEL`:
```python
# Priority 1: Explicit parameter
classifier = GroqTicketClassifier(model_name="llama-3.1-8b-instant")

# Priority 2: Environment variable
# .env: GROQ_MODEL=mixtral-8x7b-32768
classifier = GroqTicketClassifier()  # Uses mixtral-8x7b-32768

# Priority 3: Default fallback (if .env not set)
# Uses "llama-3.3-70b-versatile"
```

## Configuration File Structure

```
AI_Ticket_Routing/
├── .env                    # Active configuration (gitignored)
├── .env.example           # Template for new users
│
├── service/
│   ├── groq_classifier.py    # Reads GROQ_MODEL
│   ├── groq_rag_system.py    # Reads GROQ_MODEL + EMBEDDING_MODEL
│   └── groq_llm_judge.py     # Reads GROQ_MODEL
│
└── docs/
    └── CONFIGURATION_GUIDE.md  # Complete configuration guide
```

## Migration Checklist

- [x] Add model configuration to `.env.example`
- [x] Add model configuration to `.env`
- [x] Update `groq_classifier.py` to use environment variables
- [x] Update `groq_rag_system.py` to use environment variables
- [x] Update `groq_llm_judge.py` to use environment variables
- [x] Add `Optional` import where needed
- [x] Create configuration guide documentation
- [x] Update main README with configuration info
- [x] Test with environment variables
- [x] Verify backward compatibility (can still override)

## Testing

### Test Environment Variable Loading
```python
import os
from dotenv import load_dotenv

load_dotenv()
print(f"GROQ_MODEL: {os.getenv('GROQ_MODEL')}")
print(f"EMBEDDING_MODEL: {os.getenv('EMBEDDING_MODEL')}")
```

### Test Service Initialization
```python
from service.groq_classifier import GroqTicketClassifier

classifier = GroqTicketClassifier()
print(f"Using model: {classifier.model_name}")
# Should print: "llama-3.3-70b-versatile" (from .env)
```

## Troubleshooting

### Models not loading from .env
1. Check `.env` file exists in project root
2. Verify no typos in variable names
3. Restart Flask server to reload environment
4. Check for syntax errors in `.env` file

### Changes not taking effect
```bash
# Stop server (Ctrl+C)
# Restart server
python app.py
```

## Future Enhancements

Potential additions:
- [ ] Add `TEMPERATURE` environment variable
- [ ] Add `MAX_TOKENS` environment variable
- [ ] Add model validation on startup
- [ ] Add configuration UI in web interface
- [ ] Support for multiple API keys (load balancing)

---

**Created:** March 2026  
**Status:** Complete ✅